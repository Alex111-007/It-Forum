import requests
from bs4 import BeautifulSoup

XUY = "http://127.0.0.1:9090/index.html"
user = {
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:100.0) Gecko/20100101 Firefox/100.0'
}
headers={'user agent': user}
full_page = requests.get(XUY, headers)
soup = BeautifulSoup(full_page.content, 'html.parser')
convert = soup.findAll('h1', {
    'class': 'title'
})
print(convert[0].text)