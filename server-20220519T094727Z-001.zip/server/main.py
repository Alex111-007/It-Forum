import socket
import sys
import os
import requests
from bs4 import BeautifulSoup

API_DATE_TIME = 'http://surl.li/baidu'
API_WEB = 'http://127.0.0.1:9090/index.html'
HOST = '127.0.0.1'
PORT = 9090
user = {
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:99.0) Gecko/20100101 Firefox/99.0'
}

def start_server():
    try:
        print('подключение к серверу')
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.bind((HOST, PORT))
        sock.listen(1)
        print('подключение к серверу')
        while True:
            print("Сервер работает")
            client,addr = sock.accept()
            data = client.recv(1024).decode('utf-8')
            content = load_page(data)
            client.send(content)
            client.shutdown(socket.SHUT_WR)
        print("Pizdec")
    except:
        sock.close()
        print("Сервер был выключен")

def load_page(request_data):
    HDRS = 'HTTP/1.1 200 OK\r\Content-Type: text/html; charset=utf-8\r\n\r\n' 
    pars = request_data.split(' ')[1]
    file = ''
    with open("views" + pars, 'rb') as f:
        file = f.read()
    return HDRS.encode('utf-8') + file

def parser_date_time():
    page = requests.get(API_DATE_TIME, headers=user)
    soup = BeautifulSoup(page, 'html.parser')
    find_time = soup.findAll('div',{
        'class': 'gsrt vk_bk FzvWSb YwPhnf',
        'aria-level': '3',
        'role': 'heading'
    })
    find_date = soup.findAll('span', {
        'class': 'KfQeJ'
        })
def parser_int():
    page = requests.get(API_WEB, headers=user)
    soup = BeautifulSoup(page, 'html.parser')

    a = soup.findAll('input',{
        'id': 'one'
    })
    print(a)
    

if __name__ == '__main__':  
    start_server()
