setInterval(function () {
    document.getElementsById('date_time').innerHTML = date_time();
}, 1000);