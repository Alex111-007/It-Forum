from django.shortcuts import render
from django.utils.html import format_html

def load_course(request):
    return render(request, 'kvants/index.html')