from django.urls import path
from . import views

app_name = "link_course"
urlpattern = [
    path('page-course', views.load_course, name='it-page')
]
