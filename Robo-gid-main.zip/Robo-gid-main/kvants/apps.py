from django.apps import AppConfig


class KvantsConfig(AppConfig):
    name = 'kvants'
