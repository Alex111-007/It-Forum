from django.apps import AppConfig


class KvantProjectsConfig(AppConfig):
    name = 'kvant_projects'
