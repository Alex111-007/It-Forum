import os

from django.shortcuts import render

from kvant_projects import services


def load_main_page(request):
    return render(request, 'main_page/main.html', {'projects': services.get_projects()},)


def start_voice(request):
    os.system(r'D:\robot-site\speech\dist\new_speechnew\new_speechnew.exe D:\robot-site\speech\robot-gid-iyve-7aaaaf2bd7ea.json')
    return render(request, 'main_page/main.html', {'projects': services.get_projects()},)


def stop_voice(request):
    os.system("TASKKILL /F /IM new_speechnew.exe")
    return render(request, 'main_page/main.html', {'projects': services.get_projects()},)


def start_face(request):
    os.system(r'./face_recognition/fr_start.bat')
    return render(request, 'main_page/main.html', {'projects': services.get_projects()},)


def stop_face(request):
    os.system("./face_recognition/fr_start.bat")
    return render(request, 'main_page/main.html', {'projects': services.get_projects()},)
