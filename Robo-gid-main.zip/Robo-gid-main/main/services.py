import serial
import serial.tools.list_ports


#Find USB Port
def find_port():  #Finds which port the arduino is plugged into
    ports = list(serial.tools.list_ports.comports())
    for p in ports:
        if 'Arduino Uno' in str(p):
            return str(p).split(' ')[0]


def go_audience(num: str):
    port = find_port()
    arduino = serial.Serial()
    arduino.baudrate = 19600
    arduino.port = port
    arduino.timeout = 0.3

    arduino.write(num.encode('utf-8'))
