from django.urls import path

from . import views

app_name = 'main'
urlpatterns = [
    path('', views.load_main_page),
    path('/startvoice', views.start_voice, name='start_voice'),
    path('/stopvoice', views.stop_voice, name='stop_voice'),
    path('/startface', views.start_face, name='start_face'),
    path('/stopface', views.stop_face, name='stop_face'),
]
